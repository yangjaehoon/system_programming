#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<errno.h>
#include<string.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<readline/readline.h>


int main(int argc, char* argv[])
{
    pid_t pid;
    int status;

    char* cmdline;
    char* opt;

    while(1) {
	 
	    int i =0;
	    char* cut[100]= {NULL,};
        cmdline = readline("$ ");
        
	opt = strtok(cmdline, " ");
	if(!strcmp(opt, "quit"))
		break;

	while(opt != NULL)
	{
		cut[i] = opt;
		opt = strtok(NULL, " ");
		i++;
	}   
	pid = fork();
	if(pid >0){
		pid  = wait(&status);
	}
	else{
		if(execvp(cut[0],cut) == -1)
		{
			fprintf(stderr,"erro\n");
			exit(1);
		}
	}
    }


    return 0;
}

