#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>
int main(int argc, char* argv[])
{
	pid_t pid;
	pid = fork();
	int i =0;
	int status;

	char *arg[argc];

	for(i =0; i<(argc-1); i++){
		arg[i] = argv[i+1];
	}
	arg[i] = NULL;
	
	if(pid>0){
		printf("processing ...\n");
		pid = wait(&status);
		printf("completed");
	}
	else{
		if(execvp(argv[1], arg) == -1)
		{
			fprintf(stderr,"No such file or directory\n");
			exit(1);
		}
	}

	return 0;



}
