#include "kvs.h"

int put(kvs_t* kvs, const char* key, const char* value)
{

	printf("put: %s %s\n", key, value);
	node_t* nextNode=(node_t*)malloc(sizeof(node_t));
	node_t* cur = kvs->db;

	if(kvs->items ==0)
		kvs->db = nextNode;


	char* valueTmp = (char*)malloc(sizeof(char)*5);


	strcpy(valueTmp, value);
	nextNode->value = valueTmp;
	strcpy(nextNode->key, key);


	if(kvs->items != 0)
	{
		for(int i=0; i<kvs->items-1; i++)
			cur = cur->next;
		cur->next = nextNode;
	}
	(kvs->items) += 1;

	return 0;
}
