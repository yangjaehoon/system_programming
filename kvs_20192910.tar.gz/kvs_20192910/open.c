#include "kvs.h"

kvs_t* open()
{

	kvs_t* kvs = (kvs_t*) malloc (sizeof(kvs_t)); //fix

	if(kvs) // fix
		kvs->items = 0; // fix // (*kvs).items
		
	return kvs; // fix
}
