#include "kvs.h"

int close(kvs_t* kvs)
{
	free(kvs);
	/* do program */
	return 0;
}
