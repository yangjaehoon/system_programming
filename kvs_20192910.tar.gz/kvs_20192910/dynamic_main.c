#include "kvs.h"
#include <dlfcn.h>
#include <stdlib.h>

//void *dlopen (const char *filename, int flag);
//const char *dlerror(void);
//void *dlsym(void *handle, char *symbol);
//int dlclose(void *handle); 
int main()
{
	void *handle;
	char *error;
	kvs_t* (*open)();
	int (*put)(kvs_t*,const char*,const char*);
	char*(*get)(kvs_t*,const char*);
	int (*seek)(kvs_t*);
	int(*close)(kvs_t*);

// # /root/sp22f/kvs_lab#/root/sp22f/kvs_lab

	handle = dlopen("./libkvs.so",RTLD_LAZY);
	if(!handle)
	{
		printf("open error\n");
		fputs(dlerror(),stderr);
		exit(1);
	}
	open =(void(*))dlsym(handle, "open");
	if ((error = dlerror()) != NULL)
	{
		fputs(error, stderr);
		exit(1);
	}
	kvs_t* kvs = open();
	if(!kvs){
		printf("Failed to open kvs\n");
		return -1;
	}
	
	char key[100]; 
	char* value = (char*) malloc (sizeof(char)* 300);
	char* rvalue = (char*) malloc (sizeof(char)* 300);

	char line[255];

	FILE *f;
	f = fopen("./student.dat","r");

	printf("Put operation ...\n");
	
	put = (int(*)(kvs_t*,const char*, const char*))dlsym(handle,"put");
	while(fgets(line, sizeof(line),f) != NULL)
	{

		strcpy(key,strtok(line, " "));
		strcpy(value,strtok(NULL,"'\n"));
		
		
		if(put(kvs, key, value) < 0)
		{
			printf("Failed to put data\n");
			exit(-1);
		}
	}

	fclose(f);

	//strcpy(key, "Eunji");
	//strcpy(value, "Seoul");


	// 3. get for test 

	// 1) file read 
	// 2) get & compare return value with original vallue 

	FILE *F;
	F = fopen("./student.dat","r");

	printf("\nGet operation ...\n");
	
	get=(char*(*)(kvs_t*,const char*))dlsym(handle,"get");

	while(fgets(line, sizeof(line),f) != NULL)
	{
		strcpy(key, strtok(line, " "));
		strcpy(rvalue, strtok(NULL, "\n"));

		printf("get: %s %s\n", key, rvalue);
	}
	fclose(F);
	// 4. print all items 

	seek=(int(*)(kvs_t*))dlsym(handle,"seek");

	seek(kvs);
	printf("\n");
	//printf("%d items are found\n", nitems);


	// 5. close 
	//
	close = (int(*)(kvs_t*))dlsym(handle, "close");
	close(kvs); //주석빼야됨 나중에
	
	return 0;
}


