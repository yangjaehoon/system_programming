#include "kvs.h"

int main()
{
	// 1. create KVS
	kvs_t* kvs = open();

	if(!kvs) {
		printf("Failed to open kvs\n");
		return -1;
	}

	// 2. put data 
	
	// 1) file read 
	// 2) put data 

	char key[100]; 
	char* value = (char*) malloc (sizeof(char)* 300);
	char* rvalue = (char*) malloc (sizeof(char)* 300);

	char line[255];

	FILE *f;
	f = fopen("./student.dat","r");

	printf("Put operation ...\n");

	while(fgets(line, sizeof(line),f) != NULL)
	{

		strcpy(key,strtok(line, " "));
		strcpy(value,strtok(NULL,"'\n"));
		
		
		if(put(kvs, key, value) < 0)
		{
			printf("Failed to put data\n");
			exit(-1);
		}
	}

	fclose(f);

	//strcpy(key, "Eunji");
	//strcpy(value, "Seoul");


	// 3. get for test 

	// 1) file read 
	// 2) get & compare return value with original vallue 

	FILE *F;
	F = fopen("./student.dat","r");

	printf("\nGet operation ...\n");

	while(fgets(line, sizeof(line),f) != NULL)
	{
		strcpy(key, strtok(line, " "));
		strcpy(rvalue, strtok(NULL, "\n"));

		if(!(rvalue = get(kvs, key))){
			printf("Failed to get data\n");
			exit(-1);
		}

		printf("get: %s %s\n", key, rvalue);
	}
	fclose(F);
	// 4. print all items 

	seek(kvs);
	printf("\n");
	//printf("%d items are found\n", nitems);


	// 5. close 
	close(kvs); //주석빼야됨 나중에
	
	return 0;
}

