#include "kvs.h"

char* get(kvs_t* kvs, const char* key)
{
	/* do program here */

	char* value = (char*)malloc(sizeof(char)*100);
	node_t* tmpNode = kvs->db;
	if(!value){
		printf("Failed to malloc\n");
		return NULL;
	}
	
	for(int i=0; i<kvs->items; i++)
	{
		if(strcmp(tmpNode->key,key)==0)
			break;
		tmpNode = tmpNode ->next;
	}


	strcpy(value, tmpNode->value);
	return value;

}

