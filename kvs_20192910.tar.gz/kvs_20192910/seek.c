
#include "kvs.h"
int seek(kvs_t* kvs)
{
	printf("\nseek operation ...\n");

	int mark =0;
	node_t* curNode = (node_t*)malloc(sizeof(node_t));
	curNode = (kvs->db)->next;
	node_t* cmpNode = (node_t*)malloc(sizeof(node_t));
	cmpNode= curNode->next;
	node_t* bfrNode = kvs->db;//실제 kvs의 이전 노드
	node_t* tmpNode = (node_t*)malloc(sizeof(node_t));

	if((curNode->key)[0] > (cmpNode->key)[0])
	{
		bfrNode->next = curNode->next;
		curNode->next = bfrNode;

		kvs->db = curNode;

		curNode->next = bfrNode;
	}

	for(int i =kvs->items-2; i>0; i--)
	{
		for(int j =0; j<i; j++)
		{
			if((cmpNode->key)[0] < (curNode->key)[0])
			{
				curNode->next = cmpNode->next;
				cmpNode-> next = curNode;
				bfrNode->next =  cmpNode;

				tmpNode = cmpNode;
				cmpNode = curNode;
				curNode = tmpNode;

			}
			curNode = curNode->next;
			cmpNode = cmpNode->next;
			bfrNode = bfrNode->next;
		}

		bfrNode = kvs->db;
		curNode = bfrNode->next;
		cmpNode = curNode->next; 
		mark++;
	}


	node_t* exNode = (node_t*)malloc(sizeof(node_t));
	exNode = kvs->db;
	for(int i =0; i < kvs->items; i++)
	{
		printf("(%s, %s)\n", exNode->key, exNode->value);
		exNode = exNode->next;
	}

	return 0;
}
